class Q14_Number1s{
	public static void main(String[] args){
		ones(8);
		ones(13);
	}
	
	public static void ones(int num){ 
		int count = 0;
		while(num > 0){
            num = (num & (num - 1));
            count++;
        }
		System.out.println(count);
	} 
}