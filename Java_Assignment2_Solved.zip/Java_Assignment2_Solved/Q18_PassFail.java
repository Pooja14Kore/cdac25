class Q18_PassFail{
	public static void main(String args[]){
		check(67);
		check(36);
	}
	
	public static void check(int a){
		String result = (a>=40)? "Pass" : "Fail";
		System.out.println(result);
	}
}