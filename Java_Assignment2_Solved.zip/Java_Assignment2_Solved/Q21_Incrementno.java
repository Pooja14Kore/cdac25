class Q21_Incrementno{
	static public void main(String me[]){
		int x = 2;
		System.out.println(-~x);
	}
}