class Q5_SwapTwoNos{
	public static void main(String[] args){
		int a = 2, b = 3;
		a += b;
		a -= b;
		a = -b;
		a -= b;
		System.out.println("After Swapping:  = " + a + " = " + b); 
	}
}