class Q13_AbsoluteValue{
	public static void main(String[] args){
		abs(3);
		abs(-98);
	}
	
	public static void abs(int num){ 
		int mask = num >> 31; 
		int abs = (num + mask) ^ mask;
		System.out.println(abs);
	} 
}