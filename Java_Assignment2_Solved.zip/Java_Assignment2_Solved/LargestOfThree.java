class LargestOfThree{
	public static void main(String[] args){
		int a=1, b=2, c=3;
		int res = ((a>b && a>c)? x : (b>a && b>c)? b : c);
		System.out.println(res + " is the largest number.");
	}
}