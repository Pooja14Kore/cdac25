class Q9_SpecificRange{
	public static void main(String[] args){
		int x = 40, y = 52;
		check(x);
		check(y);
	}
	
	public static void check(int a){
		System.out.println((a>=20 && a<=50)? a + " lies within the range." : a + " doesn't lie within the range");
	} 
}