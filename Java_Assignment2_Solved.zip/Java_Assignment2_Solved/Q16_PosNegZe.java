class Q16_PosNegZe{
	public static void main(String[] args){
		poNeZe(88);
		poNeZe(-34);
		poNeZe(0);
	}
	public static void poNeZe(int x){
		String result = (x==0)? "zero" : (x>0)? "positive" : "negative";
		System.out.println(result);
	}
}