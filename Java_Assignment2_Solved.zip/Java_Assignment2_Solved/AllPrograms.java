
// Write java program to swap two nums without using third variable or +,- operator
/* class AllPrograms{
	public static void main(String args[]){
		int a = 10; int b = 20;
		a = a^b;
		b = a^b;
		a = a^b;
		System.out.println(a+" "+b);
	
	}
} */

// write a java program to check no is even or odd using bitwise & operator
/* class AllPrograms{
	public static void main(String args[]){
		int x = 8;
		if((x&1) == 0){
			System.out.println(x+" is even no");
		}
		else {
			System.out.println(x+" is even no");
		}
	}
} */

// write a program to find sum digits in a given number using % and /
 class AllPrograms {
	 public static void main(String args[]){
		 int y = 12345;
		 int sum = 0;
		 while (y>0){
		 int mod = y % 10;
		 sum = sum + mod;
		  y = y/10;
		 
		 }
		 System.out.println(sum);
	 }
 }
	