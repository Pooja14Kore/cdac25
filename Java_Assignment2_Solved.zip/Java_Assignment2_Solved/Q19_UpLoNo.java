class Q19_UpLoNo{
	public static void main(String args[]){
		alphabet('s');
		alphabet('H');
		alphabet('2');
	}
	
	public static void alphabet(char A){
		int a = (int) A;
		String result = (a>64 && a<91)? "Uppercase" : (a>96 && a<123)? "Lowercase" : "Not a character";
		System.out.println(result);
	}
}
}