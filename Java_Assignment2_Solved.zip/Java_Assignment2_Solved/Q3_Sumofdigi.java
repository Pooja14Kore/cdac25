class Q3_Sumofdigi{
	public static void main(String[] args){
		int s = 87654;
		int res = 0;
		while(s!=0){
			res = res + (s%10);
			s = s/10;
		}
		System.out.println("Sum: " + res);
	}
}