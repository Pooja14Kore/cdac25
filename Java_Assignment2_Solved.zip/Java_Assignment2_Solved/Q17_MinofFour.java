class Q17_MinofFour{
	public static void main(String[] args){
		minoffour(1,2,3,4);
	}
	
	public static void minoffour(int x, int y, int z, int m){
		int result = (x<y && x<z && x<m)? x:(z<y && z<x && z<m)? z:(y<z && y<x && y<m)? y : m;
		System.out.println(result);
	}
}